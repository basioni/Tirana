<?php
/**
 * إعدادات الووردبريس الأساسية
 *
 * عملية إنشاء الملف wp-config.php تستخدم هذا الملف أثناء التنصيب. لا يجب عليك
 * استخدام الموقع، يمكنك نسخ هذا الملف إلى "wp-config.php" وبعدها ملئ القيم المطلوبة.
 *
 * هذا الملف يحتوي على هذه الإعدادات:
 *
 * * إعدادات قاعدة البيانات
 * * مفاتيح الأمان
 * * بادئة جداول قاعدة البيانات
 * * المسار المطلق لمجلد الووردبريس
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** إعدادات قاعدة البيانات - يمكنك الحصول على هذه المعلومات من مستضيفك ** //

/** اسم قاعدة البيانات لووردبريس */
define('DB_NAME', 'tirana23_bdTor39276x');

/** اسم مستخدم قاعدة البيانات */
define('DB_USER', 'tirana23_usrToia');

/** كلمة مرور قاعدة البيانات */
define('DB_PASSWORD', '*)@P-T39p0g~');

/** عنوان خادم قاعدة البيانات */
define('DB_HOST', 'localhost');

/** ترميز قاعدة البيانات */
define('DB_CHARSET', 'utf8mb4');

/** نوع تجميع قاعدة البيانات. لا تغير هذا إن كنت غير متأكد */
define('DB_COLLATE', '');

/**#@+
 * مفاتيح الأمان.
 *
 * استخدم الرابط التالي لتوليد المفاتيح {@link https://api.wordpress.org/secret-key/1.1/salt/}
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '5--:exoW!go*6t!0PW6V^bp3+..5Gln`,w5=QCcaa2&sT%{gL!T>1mm#F#VI`lb#');
define('SECURE_AUTH_KEY',  'JDa wsAC/?Us 5|j%tBIxH,0g3JDzJ.(q?pO4[aL5Huo=H?v1qt-aaD>53]d8YZ<');
define('LOGGED_IN_KEY',    'ama}J)#/&I}^>lAgVdm&uux9Se8qW$6|F3%w1OiCR&.silVTt?uHtKPN1N8l|Tyi');
define('NONCE_KEY',        '25Y3@pu*H+~d5$?alqSRbVmn.%|w@e D_|0IFR?ha|e>|#W`}k2YKICr(1cAGfE#');
define('AUTH_SALT',        '|At)[=kC?8acGM8u`4n) !c_Y?pW%71/gO-I4$+[Jew<0mKD- Nsm(N5D_mPyQV}');
define('SECURE_AUTH_SALT', 'eF_?!R}uK9-._u0!.|Rq_;)+--Ix~E58]2@ $>&g;%fwQhmb$)Vq,,}4}MCjw-O-');
define('LOGGED_IN_SALT',   'CUdf!gBqy cUf-}l|.Od)~|?80Z*/5^j-$,ekt|*&6a}U$Q:yAbkL^ %R+ATd&%G');
define('NONCE_SALT',       'h LhxNZAJ6Z)>P#2@2 -ho|Up$Pb1>/oGm#+PYA[eAfZ:=t?[8F2G6a{{MzKYKqX');

/**#@-*/

/**
 * بادئة الجداول في قاعدة البيانات.
 *
 * تستطيع تركيب أكثر من موقع على نفس قاعدة البيانات إذا أعطيت لكل موقع بادئة جداول مختلفة
 * يرجى استخدام حروف، أرقام وخطوط سفلية فقط!
 */
$table_prefix  = 'wp_';

/**
 * للمطورين: نظام تشخيص الأخطاء
 *
 * قم بتغييرالقيمة، إن أردت تمكين عرض الملاحظات والأخطاء أثناء التطوير.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* هذا هو المطلوب، توقف عن التعديل! نتمنى لك التوفيق. */

/** المسار المطلق لمجلد ووردبريس. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** إعداد متغيرات الووردبريس وتضمين الملفات. */
require_once(ABSPATH . 'wp-settings.php');